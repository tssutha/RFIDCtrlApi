
#pragma once

#ifndef _RFID_API_H
#define _RFID_API_H

#if !defined RFID_EXT_CLASS
	#ifdef _RFID_EXT_CLASS
		#define RFID_EXT_CLASS AFX_CLASS_EXPORT
	#else
		#define RFID_EXT_CLASS AFX_CLASS_IMPORT
	#endif
#endif

#include "SerialPort.h"
#include "afxmt.h"
#include "RFIDCommands.h"
#include "RFIDConstants.h"


struct RFID_EXT_CLASS RFID_CONTROLLER_INFO
{
	CHAR cControllerType;
	CHAR cSwVerMajor;
	CHAR cSWVerMinor;
	CHAR cSwVerCorrection;
	CHAR cSwVerPoint;
	CHAR cReserved;
	CHAR cCRC[2];
	CHAR cLoaderSwVer[2];
	CHAR cProcessorId[5];
	CHAR cProcessorRfu[3];
	CHAR cProcessorSerialNo[4];
	CHAR cProcessorInternalInfo[2];
	CHAR cProcessorRsMaxP;
	CHAR cProcessorInfoCRC;
	CHAR cCheckSum; 
	CString szControllerType;
	CString szSwVer; 
	CString szSerialNo;
	CString szFirmWareCrc;
	CString szLoaderSwVer;
};

typedef struct COMM_MODE
{
	unsigned char cBaudRate : 3;  //0:9600 1:19200 2:38400 3:57600 4:115200
	unsigned char cXON      : 1;  //0: Disabled 1: Enabled
	unsigned char cReserved : 2;  // 
	unsigned char cInterface: 2;  //0:RS422 1:RS232/USB  2:RS485 3:OTHER
}COMM_MODE, *LPCOMM_MODE;

struct RFID_EXT_CLASS RFID_CONTROLLER_CONFIG
{
	//Continuous Read at PowerUp Settings
	CHAR cContReadStartAddress[2];
	CHAR cContReadBlockSize[2];
	CHAR cDuplicateReadDelay;

	CHAR cNodeId;
	CHAR cReserved1;
	CHAR cProtocol; //ABxFast = 0x00, AbxFast With CheckSum = 0x01
	CHAR cTagType;
	CHAR cReserved2;
	CHAR cCommMode;
	CHAR cOptionByte1;
	CHAR cReserved3;
	CHAR cOptionByte2;
	CHAR cControllerType;

	CHAR cSwVerMajor;
	CHAR cSWVerMinor;
	CHAR cSwVerCorrection;
	CHAR cSwVerPoint;

	CHAR cCheckSum;

	COMM_MODE stCommMode;


};






//////////////constants//////////////////////////////////
const int BIS_RFID_MAX_BUF_SIZE = 1024;
const int BIS_TAG_ID_SIZE       = 8;

/////////////////CRFIDException Class //////////////////
class /*RFID_EXT_CLASS*/ CRFIDException: public CException
{
public:
	CRFIDException();
	CRFIDException(DWORD dwLastError);
	CRFIDException(CHAR cRfidErrorCode);
	virtual ~CRFIDException();

#ifdef _DEBUG
	virtual void Dump(CDumpContext &dc) const;
#endif
	virtual BOOL GetErrorMessage(LPTSTR lpszError, UINT nMaxError, PUINT pnHelpContext= NULL);
	CString GetErrorMessage();

private:
	VOID GenerateRfidErrorMsg(CHAR cRfidErrorCode);

public:
	DWORD m_dwLastError;
	CHAR  m_cLastRFIDErrorCode;
	CString m_szRfidErrorMsg;

protected:
	DECLARE_DYNAMIC(CRFIDException);
};


class /*RFID_EXT_CLASS*/ CRFIDCtrl : public CObject
{
public:
		CRFIDCtrl();
		CRFIDCtrl(CSerialPort *pSerialPort);
		virtual ~CRFIDCtrl();

protected:

	//Syncronization Related
	CCriticalSection m_csCtrlRfidOp;

	//SerialPort Related
	INT  m_nPortId;
	BOOL m_bPortInit;
	BOOL m_bPortCreated;
	CSerialPort *m_pSerialPort;

	//RFID Device Related
    INT  m_nDeviceId;
	BOOL m_bDeviceCreated;
	CHAR m_ucRdBuffer[BIS_RFID_MAX_BUF_SIZE];
	CHAR m_ucWrBuffer[BIS_RFID_MAX_BUF_SIZE];
	CHAR m_ucTagID[BIS_TAG_ID_SIZE];
	CString m_szTagData;
	BOOL m_bTagFound;
	RFID_CONTROLLER_INFO m_stRfidControllerInfo;


	DECLARE_DYNAMIC(CRFIDCtrl);

protected:
	INT SetCommand(INT nCmd, INT nAddress =0x0000, INT nBlockSize = 0x0000,
				   BOOL bCheckSum = FALSE, CHAR *pData=NULL);
	UINT GetCheckSum( INT nBufIndex);
	INT CheckResponse(INT nWriteCmd, UINT unDataSize);
	LONG GetData(INT nCount);
	CString GetStrData(INT nCount);
	void ClearReadWriteBuffer();
	CString GetControllerTypeName(CHAR cControllerType);
	VOID DecodeCommunicationMode(CHAR cCommMode, LPCOMM_MODE lpCommMode);
	INT CheckForErrorResponse(unsigned char *pData);
	INT GetBaudRate(unsigned char ucBaudRateCode);
	INT GetDeviceInterfaceType(unsigned char ucInterfaceType);
	BOOL GetXOnState(unsigned char ucXonXoffState);
	VOID ResetTagId();
    

public:
	INT Create(CSerialPort *pSerialPort);
	INT InitComPort();
	VOID CloseComPort();
	VOID SearchRfidTag();
	VOID ReadRFIDTagId();
	VOID ReadRFIDTag(INT nAddress, INT nCount, INT nChannel=0, CHAR *pData=NULL);
	VOID WriteRFIDTag(INT nAddress, INT nCount, INT nChannel=0, CHAR *pData=NULL);
	CString GetTagDataString(INT nCount);
	CString GetTagId();
	BOOL GetSearchTagStatus();
	CString GetControllerInfo();
	VOID GetControllerConfiguration(CHAR cControllerType);
	VOID SetControllerConfiguration();

	void SetSearchTagStatus(BOOL bTagFound);
	INT WriteBonderIDToRfidTag(int nNumOfWP, CHAR *pBonderID, INT nBlockOffset);
	INT ReadBonderIDFromRfidTag(int nNumOfWP,  CHAR *pBonderID, INT nBlockOffset);
	BOOL ValidateBonderIDAtRFIDTag(int nNumOfWP, const CHAR *pBonderID,INT nBlockOffset);
#ifdef _DEBUG
	virtual void Dump(CDumpContext &dc) const;
#endif

};

#endif