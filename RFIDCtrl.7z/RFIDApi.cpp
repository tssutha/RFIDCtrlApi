#include <stdafx.h>
#include "RFIDApi.h"


#ifndef _WINERROR_
#pragma message("if you want to avoid this message, put winerror.h into precompiled"
                "header file, normally stdafx.h")
#include <winerror.h>
#endif


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CRFIDException::CRFIDException()
:CException()
,m_dwLastError(0)
{

}

CRFIDException::CRFIDException(DWORD dwLastError)
:CException()
,m_dwLastError(dwLastError)
{

}

CRFIDException::CRFIDException(CHAR cRfidErrorCode)
:CException()
,m_dwLastError(0)
,m_cLastRFIDErrorCode(cRfidErrorCode)
{
   GenerateRfidErrorMsg(cRfidErrorCode);
   //AfxMessageBox(m_szRfidErrorMsg);
}

CRFIDException::~CRFIDException()
{

}

IMPLEMENT_DYNAMIC(CRFIDException, CException)

#ifdef _DEBUG
void CRFIDException::Dump(CDumpContext &dc) const
{
	CObject::Dump(dc);
	dc << _T("m_dwLastError = ") <<m_dwLastError << _T("\0");
}
#endif

BOOL CRFIDException::GetErrorMessage(LPTSTR lpszError, UINT nMaxError, PUINT pnHelpContext)
{
	//validate the inputs
   ASSERT(lpszError != NULL && AfxIsValidString(lpszError, nMaxError));
   if(pnHelpContext != NULL)
	   pnHelpContext = 0;

   BOOL bSuccess = FALSE;

   LPTSTR lpBuffer;
   DWORD dwReturn = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
						 NULL, m_dwLastError, MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
						 reinterpret_cast<LPTSTR>(&lpBuffer), 0, NULL);

   if(dwReturn == 0)
	   lpszError = _T("\0");
   else
   {
	   bSuccess = TRUE;
	   CString szErrMsg;
	   szErrMsg.Format("RFID Controller Operation Error \n%s", m_szRfidErrorMsg);
	   strncpy(lpszError,szErrMsg.GetBuffer(4096), nMaxError);
	   szErrMsg.ReleaseBuffer();
   }
   return TRUE;
}

CString CRFIDException::GetErrorMessage()
{
	CString szRetVal;
	LPTSTR lpszError = szRetVal.GetBuffer(4096);
	GetErrorMessage(lpszError, 4096);
	szRetVal.ReleaseBuffer();
	return szRetVal + m_szRfidErrorMsg;
}

VOID CRFIDException::GenerateRfidErrorMsg(CHAR cRfidErrorCode)
{
	unsigned char ucErrorCode = (unsigned char) cRfidErrorCode;
	switch(cRfidErrorCode)
	{
	case ABx_FAST_ERR_FILL_TAG_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = FILL_TAG_FAILED",ucErrorCode);
		break;
	case ABx_FAST_ERR_READ_DATA_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = READ_DATA_FAILED",ucErrorCode);
		break;
	case ABx_FAST_ERR_WRITE_DATA_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = WRITE_DATA_FAILED",ucErrorCode);
		break;
	case ABx_FAST_ERR_READ_TAG_ID_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = READ_TAG_ID_FAILED",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_SYNTAX:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_SYNTAX",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_TAG_TYPE:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_TAG_TYPE",ucErrorCode);
		break;
	case ABx_FAST_ERR_LOCK_TAG_BLOCK_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = LOCK_TAG_BLOCK_FAILED",ucErrorCode);
		break;
	case ABx_FAST_ERR_INTERNAL_CONTOLLER_ERROR:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INTERNAL_CONTOLLER_ERROR",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_CONTROLLER_TYPE:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_CONTROLLER_TYPE",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_PROGRAMMING_ADDRESS:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_PROGRAMMING_ADDRESS",ucErrorCode);
		break;
	case ABx_FAST_ERR_CRC_ERROR:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \n ErrorDesc = CRC_ERROR",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_SOFTWARE_VERSION:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_SOFTWARE_VERSION",ucErrorCode);
		break;
	case ABx_FAST_ERR_INVALID_RESET:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = INVALID_RESET",ucErrorCode);
		break;
	case ABx_FAST_ERR_SET_CONFIGURATION_ERROR:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = SET_CONFIGURATION_ERROR",ucErrorCode);
		break;
	case ABx_FAST_ERR_GET_CONGIGURATION_ERROR:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = GET_CONGIGURATION_ERROR",ucErrorCode);
		break;

	//custom Error Code
	case RFID_OP_CUSTOM_ERR_PORT_IS_OPEN:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = PORT_IS_OPEN",ucErrorCode);
		break;
	case RFID_OP_CUSTOM_ERR_PORT_IS_NOT_CREATED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = PORT_IS_NOT_CREATED",ucErrorCode);
		break;
	case RFID_OP_CUSTOM_ERR_CREATE_PORT_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = CREATE_PORT_FAILED",ucErrorCode);
		break;
	case RFID_OP_CUSTOM_ERR_PORT_IS_ALREADY_CREATED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = PORT_IS_ALREADY_CREATED",ucErrorCode);
		break;
	case RFID_OP_CUSTOM_ERR_PORT_OPEN_FAILED:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \nErrorDesc = PORT_OPEN_FAILED",ucErrorCode);
		break;

	default:
		m_szRfidErrorMsg.Format("ErrorCode = 0x%02x \n UNKNOWN ERROR",ucErrorCode); 

	}

}


/////////////CRFIDCtrl Class Related////////////////////////////////////

CRFIDCtrl::CRFIDCtrl()
:m_pSerialPort(NULL)
,m_bPortCreated(FALSE)
,m_bPortInit(FALSE)
,m_bDeviceCreated(FALSE)
,m_nDeviceId(0x00)
,m_nPortId(1)
,m_bTagFound(FALSE)
{

}


CRFIDCtrl::CRFIDCtrl(CSerialPort *pSerialPort)
:m_pSerialPort(pSerialPort)
,m_bTagFound(FALSE)
{

}

CRFIDCtrl::~CRFIDCtrl()
{

}

IMPLEMENT_DYNAMIC(CRFIDCtrl, CObject)

#ifdef _DEBUG
void CRFIDCtrl::Dump(CDumpContext &dc) const
{
	CObject::Dump(dc);
	dc << _T("RFIDController");
}
#endif

INT CRFIDCtrl::Create(CSerialPort *pSerialPort)
{
	CSingleLock lock(&m_csCtrlRfidOp);
	lock.Lock();

	try
	{
		if(m_bPortCreated == TRUE)
		{
			TRACE("COM Port is already created");
			//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_PORT_IS_ALREADY_CREATED));
			return RFID_NOK;
		}

		m_pSerialPort = pSerialPort;
		m_bPortCreated = TRUE;

		m_nDeviceId = 100;
		lock.Unlock();
	}
	catch(CException *e)
	{
		lock.Unlock();
		TRACE("Error during COM PORT Creation.");
		//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_CREATE_PORT_FAILED));	
		return RFID_NOK;

	}
	return RFID_OK;
}

INT CRFIDCtrl::InitComPort()
{
	CSingleLock lock(&m_csCtrlRfidOp);
	lock.Lock();

	try
	{
		if(m_pSerialPort->IsOpen())
		{
			TRACE("COM Port is already opened");
			//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_PORT_IS_OPEN));
			return RFID_NOK;
		}

		m_pSerialPort->Open(3);
		m_nPortId = 3;

		COMMCONFIG stCommConfig;
		m_pSerialPort->GetConfig(stCommConfig);
		COMMTIMEOUTS stComTimeOut;
		m_pSerialPort->GetTimeouts(stComTimeOut);
		stComTimeOut.ReadTotalTimeoutMultiplier = 50;
		stComTimeOut.ReadTotalTimeoutConstant = 100;
		m_pSerialPort->SetTimeouts(stComTimeOut);
		

		DWORD dwBaudRate = stCommConfig.dcb.BaudRate;

		m_bPortInit = TRUE;
		lock.Unlock();
	}
	catch(CException *e)
	{
		lock.Unlock();
		TRACE("COM Port is already opened");
		//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_PORT_OPEN_FAILED));
		return RFID_NOK;
	}

	return RFID_OK;

}
VOID CRFIDCtrl::CloseComPort()
{
	CSingleLock lock(&m_csCtrlRfidOp);
	lock.Lock();
	m_pSerialPort->Close();
	lock.Unlock();
}

INT CRFIDCtrl::SetCommand(INT nCmd, INT nAddress, INT nBlockSize, BOOL bCheckSum, CHAR *pData)
{
	CString szParameter;
	CSingleLock lock(&m_csCtrlRfidOp);
	INT nBufCount	=0;
	UINT unCheckSum =0;
	UINT unCmdSize =0 ;
	UINT unDataSize = 0;
	BOOL bConsiderAddressBlock = FALSE;
	INT nStatus = RFID_OK;

	if(m_bPortInit == FALSE)
	{
		TRACE("Serial Port is not initialized.");
		//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_PORT_IS_NOT_CREATED));
		return RFID_NOK;
	}

	lock.Lock();
	m_pSerialPort->Purge(PURGE_RXABORT|PURGE_RXCLEAR|PURGE_TXABORT|PURGE_TXCLEAR);
	Sleep(20);

	//Command Header
	m_ucWrBuffer[nBufCount++] = ABx_FAST_CMD_HEADER;
	m_ucWrBuffer[nBufCount++] = ABx_FAST_CMD_HEADER;

	//Command Size
	switch(nCmd)
	{
	case ABx_FAST_CMD_FILL_TAG: 
		m_ucWrBuffer[nBufCount++] = ABx_FAST_FILL_TAG_COMMAND_SIZE >> 8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_FILL_TAG_COMMAND_SIZE & 0xFF;
		unDataSize = ABx_FAST_FILL_TAG_RESP_SIZE;
		bConsiderAddressBlock = TRUE;
		break;	
	case ABx_FAST_CMD_READ_TAG:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAG_COMMAND_SIZE >> 8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAG_COMMAND_SIZE & 0xFF;
		unDataSize = ABx_FAST_READ_TAG_RESP_SIZE + nBlockSize;
		bConsiderAddressBlock = TRUE;
		break;
	case ABx_FAST_CMD_WRITE_TAG:
		m_ucWrBuffer[nBufCount++] = (ABx_FAST_WRITE_TAG_COMMAND_SIZE + nBlockSize) >> 8;
		m_ucWrBuffer[nBufCount++] = (ABx_FAST_WRITE_TAG_COMMAND_SIZE + nBlockSize) & 0xFF;
		unDataSize = ABx_FAST_WRITE_TAG_RESP_SIZE;
		bConsiderAddressBlock = TRUE;
		break;	
	case ABx_FAST_CMD_READ_TAG_ID:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAG_ID_COMMAND_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAG_ID_COMMAND_SIZE & 0xFF;
		unDataSize = ABx_FAST_READ_TAGID_RESP_SIZE;
		ResetTagId();
		break; 
	case ABx_FAST_CMD_TAG_SEARCH:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_TAG_SEARCH_COMMAND_SIZE >> 8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_TAG_SEARCH_COMMAND_SIZE & 0xFF;
		unDataSize = ABx_FAST_TAG_SEARCH_RESP_SIZE;
		break;
	case ABx_FAST_CMD_READ_TAGID_AND_DATA:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAGID_AND_DATA_CMD_SIZE >> 8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_READ_TAGID_AND_DATA_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_READ_TAGID_AND_DATA_RESP_SIZE + nBlockSize;
		bConsiderAddressBlock = TRUE;
		break;
		/*case ABx_FAST_CMD_LOCK_MEMORY_BLOCK:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_LOCK_MEMORY_BLOCK_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_LOCK_MEMORY_BLOCK_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_LOCK_MEMORY_BLOCK_RESP_SIZE;
		break;
		case ABx_FAST_CMD_RESET_CONTROLLER:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_RESET_CONTROLLER_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_RESET_CONTROLLER_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_RESET_CONTROLLER_RESP_SIZE;
		break;
		case ABx_FAST_CMD_SET_CONTROLLER_CONFIGURATION:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_SET_CONTROLLER_CONFIG_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_SET_CONTROLLER_CONFIG_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_SET_CONTROLLER_CONFIG_RESP_SIZE;
		break;
		case ABx_FAST_CMD_GET_CONTROLLER_CONFIGURATION:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_GET_CONTROLLER_CONFIG_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_GET_CONTROLLER_CONFIG_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_GET_CONTROLLER_CONFIG_RESP_SIZE;
		break;
		case ABx_FAST_CMD_GET_CONTROLLER_INFO:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_GET_CONTROLLER_INFO_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_GET_CONTROLLER_INFO_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_GET_CONTROLLER_CONFIG_RESP_SIZE;
		break;
		case ABx_FAST_CMD_SET_CONTROLLER_TIME:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_SET_CONTROLLER_TIME_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_SET_CONTROLLER_TIME_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_SET_CONTROLLER_TIME_RESP_SIZE;
		break;
		case ABx_FAST_CMD_EXECUTE_MACRO:
		m_ucWrBuffer[nBufCount++] = ABx_FAST_EXECUTE_MACRO_CMD_SIZE >>8;
		m_ucWrBuffer[nBufCount++] = ABx_FAST_EXECUTE_MACRO_CMD_SIZE & 0xFF;
		unDataSize = ABx_FAST_EXECUTE_MACRO_RESP_SIZE;
		break;
		*/
	default:
		unDataSize = nBufCount + nBlockSize;
	}

	//CommandID
	m_ucWrBuffer[nBufCount++] = nCmd;

	//Not every command needs a Start Address and Memory Block Size
	//to be manipulated
	if(bConsiderAddressBlock == TRUE)
	{
		//Start Address
		m_ucWrBuffer[nBufCount++] = nAddress >> 8;
		m_ucWrBuffer[nBufCount++] = nAddress & 0xFF;

		//Read/Write Block Size
		m_ucWrBuffer[nBufCount++] = nBlockSize >> 8;
		m_ucWrBuffer[nBufCount++] = nBlockSize & 0xFF;
	}


	//Timeout Value
	m_ucWrBuffer[nBufCount++] = ABx_FAST_TIMEOUT >> 8;
	m_ucWrBuffer[nBufCount++] = ABx_FAST_TIMEOUT & 0xFF;

	//Data Byte Value, Optional
	switch(nCmd)
	{
	case ABx_FAST_CMD_FILL_TAG:
		m_ucWrBuffer[nBufCount++] = pData[0];
		break;
	case ABx_FAST_CMD_WRITE_TAG:
		for(int i=0; i< nBlockSize; i++)
		{
			m_ucWrBuffer[nBufCount++] = pData[i];
		}
		break;
	}
	//CheckSum ,Optional
	/*Calculate CheckSum and Apply*/
	if(bCheckSum == TRUE)
	{
		m_ucWrBuffer[nBufCount++] = GetCheckSum(nBufCount);
	}

	//Command Terminator
	m_ucWrBuffer[nBufCount++] = ABx_FAST_CMD_TERMINATOR;


	//Execute the Command
	m_pSerialPort->Write(m_ucWrBuffer,nBufCount);
	//Wait for sufficient time to complete the operation
	//Sleep(10/*(nbufcount + nblocksize)*15*/);

	lock.Unlock();
	//Check the response	
	unDataSize = ABx_FAST_RESPONSE_PACKET_HEADER_TERMINATOR + unDataSize;
	nStatus = CheckResponse(nCmd, unDataSize);
	//m_pSerialPort->Read(&m_ucRdBuffer,unDataSize);
	//int x = 100;

	lock.Unlock();

	return nStatus;

}

INT CRFIDCtrl::CheckResponse( INT nWriteCmd, UINT unDataSize)
{ 	
	CSingleLock lock(&m_csCtrlRfidOp);
	lock.Lock(); 
	int nIndex =0;
	ClearReadWriteBuffer();
	m_pSerialPort->Read(&m_ucRdBuffer,unDataSize);
	CHAR cIsError = m_ucRdBuffer[4];
	CHAR cErrorCode = 0x00;

	//Received Error Data packet, 
	if(cIsError == 0xFFFFFFFF) //0xFF
	{
		int x = 100;
		//handle error here
		cErrorCode = m_ucRdBuffer[5]; 
		TRACE("Command Execuation, Error Reported");
		return RFID_NOK;
	}

	INT nReadCmd = (INT)m_ucRdBuffer[4];
	if(nWriteCmd != nReadCmd)
	{

		return RFID_NOK;
	}
	m_bTagFound = TRUE;

	INT nBlockSize = (INT)((m_ucRdBuffer[2] << 8) |m_ucRdBuffer[3]) - 0x0001;


	int nStartIndex  = 5;
	switch(nWriteCmd)
	{
	case ABx_FAST_CMD_READ_TAG:
		for(int i=nStartIndex; i< nStartIndex + nBlockSize; i++)
		{
			m_szTagData += m_ucRdBuffer[i];
		}
		break;
	case ABx_FAST_CMD_READ_TAG_ID:			
		for(int i=nStartIndex; i< nStartIndex + nBlockSize; i++)
		{
			m_ucTagID[nIndex++] = m_ucRdBuffer[i];
		}
		break;
	case ABx_FAST_CMD_READ_TAGID_AND_DATA:
		for(int i=nStartIndex; i< (nStartIndex+8); i++)
		{
			m_ucTagID[nIndex++] = m_ucRdBuffer[i];
		}
		nBlockSize = (INT)m_ucRdBuffer[3] - 0x0001 - 0x0008;
		nStartIndex = nStartIndex + 8;
		for(int i=nStartIndex; i < nStartIndex + nBlockSize; i++)
		{
			m_szTagData += m_ucRdBuffer[i];
		}
		break;											 

	}



	return RFID_OK;
}

/*
	Calculate CheckSum for ABx Fast RFID communication 
	protocol.
	CheckSum = 0xFF - (CommandSize + CommandID + StartAddress + BlockSize + TimeOut + DataBytes)
*/
UINT CRFIDCtrl::GetCheckSum(INT nBufIndex)
{
	UINT unCheckSum = 0x00;
	try
	{
		for(int i=1; i < nBufIndex; i++)
		{
		   unCheckSum += m_ucWrBuffer[i];
		}

		unCheckSum = 0xFF - unCheckSum;

	}
	catch(CException *e)
	{
		TRACE("Error occured during CHECKSUM calculation");
	}

	return unCheckSum;

}

void CRFIDCtrl::ClearReadWriteBuffer()
{
	memset(m_ucRdBuffer,0,BIS_RFID_MAX_BUF_SIZE);

}

CString CRFIDCtrl::GetControllerTypeName(CHAR cControllerType)
{
	CString szCtrlName("Not Known");
	if(cControllerType == BIS_M_62_)
		szCtrlName = CTRL_TYPE_BIS_M_62;
	else if(cControllerType == BIS_M_410_)
		szCtrlName = CTRL_TYPE_BIS_M_410;
	else if(cControllerType == BIS_M_411_)
		szCtrlName = CTRL_TYPE_BIS_M_411;
	else if(cControllerType == BIS_U_62_)
		szCtrlName = CTRL_TYPE_BIS_U_62;
	else
		szCtrlName = CTRL_TYPE_BIS_M_410;

	return szCtrlName;
}

CString CRFIDCtrl::GetTagDataString(INT nCount)
{
    return m_szTagData;	
}
CString CRFIDCtrl::GetTagId()
{
	CString szTagIdHex;
	for(int i=0; i < 8; i++)
	{
		CString szTemp;
		szTemp.Format(_T("%02X"), (unsigned char)m_ucTagID[i]);
		szTagIdHex +=szTemp;
	}
	return szTagIdHex;

}

VOID CRFIDCtrl::ResetTagId()
{
    for(int i=0; i < 8; i++)
	{
		m_ucTagID[i] = ' ';
	}
}

void CRFIDCtrl::SetSearchTagStatus(BOOL bTagFound)
{
	m_bTagFound = bTagFound;
}

BOOL CRFIDCtrl::GetSearchTagStatus()
{
	BOOL bTagFound = m_bTagFound;
	//SetSearchTagStatus(FALSE);
	//DecodeCommunicationMode(0x44);
	return bTagFound;
}

INT CRFIDCtrl::CheckForErrorResponse(unsigned char *pData)
{
	if(pData == NULL)
		return RFID_NOK;

	//Check for ErrorCode
	unsigned char cIsError = pData[4];
	unsigned char cErrorCode = 0x00;
	//Received Error Data packet, 
	if(cIsError == 0xFF) //0xFF
	{
		//handle error here
		cErrorCode = pData[5]; 
		TRACE("Get Controller Info, Error Reported");
		THROW(new CRFIDException((CHAR)cErrorCode));
		return RFID_NOK;
	}

	return RFID_OK;
}

VOID  CRFIDCtrl::SearchRfidTag()
{
	SetCommand(ABx_FAST_CMD_TAG_SEARCH);    
}

VOID CRFIDCtrl::ReadRFIDTagId()
{
	SetCommand(ABx_FAST_CMD_READ_TAG_ID);
}

VOID CRFIDCtrl::ReadRFIDTag(INT nAddress, INT nCount, INT nChannel, CHAR *pData)
{
	SetCommand(ABx_FAST_CMD_READ_TAG, nAddress, nCount);


}
VOID CRFIDCtrl::WriteRFIDTag(INT nAddress, INT nCount, INT nChannel, CHAR *pData)
{
	SetCommand(ABx_FAST_CMD_WRITE_TAG, nAddress, nCount, FALSE, pData);

}

INT CRFIDCtrl::WriteBonderIDToRfidTag(int nNumOfWP,  CHAR *pBonderID, INT nBlockOffset)
{
	INT nStatus = RFID_OK;
	if(pBonderID == NULL)
		return RFID_NOK;

	for(int i=0; i < nNumOfWP; i++)
	{
		 WriteRFIDTag(nBlockOffset + i*100, 0x0002, 0, pBonderID);
	}
   return nStatus;
}

INT CRFIDCtrl::ReadBonderIDFromRfidTag(int nNumOfWP,  CHAR *pBonderID, INT nBlockOffset)
{
	INT nStatus = RFID_OK;
	INT nStartAddress = 0x00;
	INT nBlockCount = nNumOfWP * 100;

	 ReadRFIDTag(nStartAddress,nBlockCount);
	if(nStatus == RFID_OK)
	{
		CString szTagData = GetTagDataString(0x30);
		CString szBonderID = szTagData.Left(nBlockOffset +2).Right(2);

		pBonderID[0] = szBonderID[0];
		pBonderID[1] = szBonderID[1];
		

	}
	else
	{
	  nStatus = RFID_NOK;
	}

	return nStatus;

}
BOOL CRFIDCtrl::ValidateBonderIDAtRFIDTag(int nNumOfWP, const CHAR *pBonderID, INT nBlockOffset)
{
	CHAR cBonderID[3] = {'0','0','\0'};
	INT nStatus = ReadBonderIDFromRfidTag(nNumOfWP,cBonderID, nBlockOffset);
	if(nStatus == RFID_OK)
	{
		CString szInputBonderID, szOutputBonderID;
		szInputBonderID.Format("%s", pBonderID);
		szOutputBonderID.Format("%s", cBonderID);

		if(szInputBonderID.Compare(szOutputBonderID)== 0)
            return TRUE;
		else
			return FALSE;
	}
	else
	{
		return FALSE;
	}
}

CString CRFIDCtrl::GetControllerInfo()
{
	//Read Buffer
	unsigned char ucRdCtrlInfo[48];
	//Write Buffer
	CHAR ucWrCtrlInfo[] = {
		ABx_FAST_CMD_HEADER,ABx_FAST_CMD_HEADER, /*Command Header     0x02, 0x02*/
		0x00,0x01,                               /*Command Size       0x0001    */
		0x69/*ABx_FAST_CMD_GET_CONTROLLER_INFO*/,        /*Command ID         0x38      */
		ABx_FAST_CMD_TERMINATOR};				 /*Command Terminator 0x03      */

	if(m_bPortInit == FALSE)
	{
		TRACE("Serial Port is not initialized.");
		THROW(new CRFIDException());
	}

	CSingleLock lock(&m_csCtrlRfidOp);
	//try
	//{
		lock.Lock();
		m_pSerialPort->Purge(PURGE_RXABORT|PURGE_RXCLEAR|PURGE_TXABORT|PURGE_TXCLEAR);

		//Execute the Command
		m_pSerialPort->Write(ucWrCtrlInfo,6);
		//Wait for sufficient time to complete the operation
		Sleep(6 *15);
		//Check the response	
		m_pSerialPort->Read(&ucRdCtrlInfo,32);

		//Check for Error Response
		if(CheckForErrorResponse(ucRdCtrlInfo) == RFID_NOK)
			return "Error Reported";

		//Convert Byte Array to Control Info structure
		int nIndex = 5;
		//Controller Type
		m_stRfidControllerInfo.cControllerType = ucRdCtrlInfo[nIndex++];

		//Controller Software Infomation
		//Sw Version = Major.Minor.Correction.Point
		m_stRfidControllerInfo.cSwVerMajor     = ucRdCtrlInfo[nIndex++];
		m_stRfidControllerInfo.cSWVerMinor     = ucRdCtrlInfo[nIndex++];
		m_stRfidControllerInfo.cSwVerCorrection= ucRdCtrlInfo[nIndex++];
		m_stRfidControllerInfo.cSwVerPoint     = ucRdCtrlInfo[nIndex++];

		//Reserved Byte
		m_stRfidControllerInfo.cReserved = ucRdCtrlInfo[nIndex++];

		//Software CRC
		m_stRfidControllerInfo.cCRC[0] = ucRdCtrlInfo[nIndex++];
		m_stRfidControllerInfo.cCRC[1] = ucRdCtrlInfo[nIndex++];

		//Loader Software version
		m_stRfidControllerInfo.cLoaderSwVer[0] = ucRdCtrlInfo[nIndex++];
		m_stRfidControllerInfo.cLoaderSwVer[1] = ucRdCtrlInfo[nIndex++];

		//Processor ID
		for(int i = 0; i < 5; i++)
			m_stRfidControllerInfo.cProcessorId[i] = ucRdCtrlInfo[nIndex++];

		//Processor RFU
		for(int i=0; i<3; i++)
			m_stRfidControllerInfo.cProcessorRfu[i] = ucRdCtrlInfo[nIndex++];

		//Processor Serial Number
		for(int i=0; i<4; i++)
			m_stRfidControllerInfo.cProcessorSerialNo[i] = ucRdCtrlInfo[nIndex++];

		//Processor Internal Info
		for(int i=0; i<2; i++)
			m_stRfidControllerInfo.cProcessorInternalInfo[i] = ucRdCtrlInfo[nIndex++];

		//Processor RsMaxP
		m_stRfidControllerInfo.cProcessorRsMaxP = ucRdCtrlInfo[nIndex++];

		//Processor Information CRC 
		m_stRfidControllerInfo.cProcessorInfoCRC = ucRdCtrlInfo[nIndex++];

		//Check Sum
		m_stRfidControllerInfo.cCheckSum = ucRdCtrlInfo[nIndex++];



		//Get RFID Controller Info , as String Data
		m_stRfidControllerInfo.szControllerType = GetControllerTypeName(m_stRfidControllerInfo.cControllerType);

		m_stRfidControllerInfo.szSwVer.Format(_T("%d.%d.%c.%d"),m_stRfidControllerInfo.cSwVerMajor,
			m_stRfidControllerInfo.cSWVerMinor,
			m_stRfidControllerInfo.cSwVerCorrection,
			m_stRfidControllerInfo.cSwVerPoint);
		m_stRfidControllerInfo.szSwVer.MakeUpper();


		m_stRfidControllerInfo.szSerialNo.Format(_T("%02x%02x%02x%02x"),
			(unsigned char)m_stRfidControllerInfo.cProcessorSerialNo[0],
			(unsigned char)m_stRfidControllerInfo.cProcessorSerialNo[1],
			(unsigned char)m_stRfidControllerInfo.cProcessorSerialNo[2],
			(unsigned char)m_stRfidControllerInfo.cProcessorSerialNo[3]);
		m_stRfidControllerInfo.szSerialNo.MakeUpper();


		m_stRfidControllerInfo.szFirmWareCrc.Format(_T("%02x%02x"),
			(unsigned char)m_stRfidControllerInfo.cCRC[0],
			(unsigned char)m_stRfidControllerInfo.cCRC[1]);
		m_stRfidControllerInfo.szFirmWareCrc.MakeUpper();														


		CString szTemp;
		szTemp.Format(_T("%02x%02x"),
			(unsigned char)m_stRfidControllerInfo.cLoaderSwVer[0],
			(unsigned char)m_stRfidControllerInfo.cLoaderSwVer[1]); 
		m_stRfidControllerInfo.szLoaderSwVer.Format(_T("%c.%c.%c.%c"),szTemp[0], szTemp[1], szTemp[2], szTemp[3]);
		m_stRfidControllerInfo.szLoaderSwVer.MakeUpper();
	//}
	//catch(CRFIDException *e)
	//{
		lock.Unlock();
		//THROW(new CRFIDException((CHAR)RFID_OP_CUSTOM_ERR_ERROR_DURING_CMD_EXECU));
	//	AfxMessageBox(e->GetErrorMessage());
	//}   


	CString szCtrlInfo;
	szCtrlInfo.Format(_T("Type: %s\n SwVer: %s\n FirmwareCRC: %s\n SerialNo: %s\n LoaderSwVer: %s\n")
					  ,m_stRfidControllerInfo.szControllerType
					  ,m_stRfidControllerInfo.szSwVer
					  ,m_stRfidControllerInfo.szFirmWareCrc
					  ,m_stRfidControllerInfo.szSerialNo
					  ,m_stRfidControllerInfo.szLoaderSwVer);
	lock.Unlock();
	return szCtrlInfo;


}

VOID CRFIDCtrl::GetControllerConfiguration(CHAR cControllerType)
{
	//Read Buffer
	unsigned char ucRdCtrlInfo[32] = {0};
	//Write Buffer
	CHAR ucWrCtrlInfo[] = {
		ABx_FAST_CMD_HEADER,ABx_FAST_CMD_HEADER,  /*Command Header     0x02, 0x02*/
		0x00,0x02,                                /*Command Size       0x0001    */
        ABx_FAST_CMD_GET_CONTROLLER_CONFIGURATION,/*Command ID         0x38      */
		0x01,                                     /*Controller Type    0x03      */ //0x03- BIS_M_410
		ABx_FAST_CMD_TERMINATOR};				  /*Command Terminator 0x03      */
	
	CSingleLock lock(&m_csCtrlRfidOp);

	if(m_bPortInit == FALSE)
	{
		TRACE("Serial Port is not initialized.");
		THROW(new CRFIDException());
	}

	try{

		lock.Lock();
		//Execute the Command
		m_pSerialPort->Write(ucWrCtrlInfo,6);
		//Wait for sufficient time to complete the operation
		Sleep(6 *15);
		//Check the response	
		m_pSerialPort->Read(&ucRdCtrlInfo,26);

		//Check for Error Response
		if(CheckForErrorResponse(ucRdCtrlInfo) == RFID_NOK)
			return;

		//Received Correct Reponse, process the data
		int x= 0;
	}
	catch(CException *e)
	{
		lock.Unlock();

	}

	lock.Unlock();

}
VOID CRFIDCtrl::SetControllerConfiguration()
{

}

VOID CRFIDCtrl::DecodeCommunicationMode(CHAR cCommMode, LPCOMM_MODE lpCommMode)
{
	lpCommMode->cBaudRate =  (unsigned char)cCommMode & 0x07;
	lpCommMode->cXON      =  ((unsigned char)cCommMode & 0x08) >> 3;
	lpCommMode->cReserved =  ((unsigned char)cCommMode & 0x30) >> 4;
	lpCommMode->cInterface=  ((unsigned char)cCommMode & 0xC0) >> 6;
}

INT CRFIDCtrl::GetBaudRate(unsigned char ucBaudRateCode)
{
	INT nBaudRate = 9600;
	switch(ucBaudRateCode)
	{
	case 0: nBaudRate = 9600;  break;
	case 1: nBaudRate = 19200; break;
	case 2: nBaudRate = 38400; break;
	case 3: nBaudRate = 57600; break;
	case 4: nBaudRate = 115200; break;
	default:
		nBaudRate = 9600;
	}
	return nBaudRate;
}

INT CRFIDCtrl::GetDeviceInterfaceType(unsigned char ucInterfaceType)
{
	INT nDeviceInterfaceType = RFID_COM_RS232_USB;

	switch(ucInterfaceType)
	{
	case 0: nDeviceInterfaceType = RFID_COM_RS422; break;
	case 1: nDeviceInterfaceType = RFID_COM_RS232_USB; break;
	case 2: nDeviceInterfaceType = RFID_COM_RS485; break;
	case 3: nDeviceInterfaceType = RFID_COM_OTHER; break;		
	}

	return nDeviceInterfaceType;

}
BOOL CRFIDCtrl::GetXOnState(unsigned char ucXonXoffState)
{
	if(ucXonXoffState == 0)
		return FALSE; //Disabled
	else
		return TRUE; //Enabled 

}
